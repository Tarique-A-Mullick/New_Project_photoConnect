"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, Star, MapPin, Calendar, Camera, Share2, MessageCircle, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Mock photographer data
const mockPhotographer = {
  id: "1",
  name: "Sarah Johnson",
  bio: "Professional wedding and portrait photographer with over 8 years of experience. I specialize in capturing authentic moments and emotions that tell your unique story. My style blends photojournalistic candids with artistic portraits.",
  specialties: ["Wedding", "Portrait", "Engagement"],
  location: "New York, NY",
  rating: 4.9,
  reviewCount: 127,
  price: "$200/hour",
  availability: "Available",
  image: "/professional-female-photographer.png",
  coverImage: "/photography-studio.png",
  experience: "8+ years",
  completedSessions: 450,
  responseTime: "Within 2 hours",
  packages: [
    {
      name: "Basic Portrait Session",
      price: "$200",
      duration: "1 hour",
      photos: "15 edited photos",
      features: ["1 hour session", "15 high-res edited photos", "Online gallery", "Print release"],
    },
    {
      name: "Wedding Photography",
      price: "$2,500",
      duration: "8 hours",
      photos: "300+ edited photos",
      features: [
        "8 hours coverage",
        "300+ edited photos",
        "Online gallery",
        "USB drive",
        "Print release",
        "Engagement session",
      ],
    },
    {
      name: "Event Photography",
      price: "$150/hour",
      duration: "Flexible",
      photos: "50+ per hour",
      features: ["Professional coverage", "50+ photos per hour", "Same-day preview", "Online gallery"],
    },
  ],
  equipment: [
    "Canon EOS R5",
    "Canon 24-70mm f/2.8L",
    "Canon 85mm f/1.4L",
    "Professional lighting kit",
    "Backup equipment",
  ],
  portfolio: [
    "/bride-portrait.png",
    "/portrait-couple.png",
    "/outdoor-engagement.png",
    "/wedding-ceremony.png",
    "/family-portrait.png",
    "/wedding-reception-joy.png",
  ],
  reviews: [
    {
      id: "1",
      name: "Emily Chen",
      rating: 5,
      date: "2 weeks ago",
      comment:
        "Sarah was absolutely amazing! She captured our wedding day perfectly and made us feel so comfortable. The photos are stunning and we couldn't be happier.",
    },
    {
      id: "2",
      name: "Michael Rodriguez",
      rating: 5,
      date: "1 month ago",
      comment:
        "Professional, creative, and so easy to work with. Sarah's portrait session exceeded our expectations. Highly recommend!",
    },
    {
      id: "3",
      name: "Jessica Park",
      rating: 5,
      date: "2 months ago",
      comment:
        "Sarah photographed our engagement and we loved every single photo. She has such a great eye for capturing natural moments.",
    },
  ],
}

export default function PhotographerProfile() {
  const params = useParams()
  const [activeTab, setActiveTab] = useState("portfolio")

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${mockPhotographer.name} - Professional Photographer`,
        text: `Check out ${mockPhotographer.name}'s photography portfolio`,
        url: window.location.href,
      })
    } else {
      navigator.clipboard.writeText(window.location.href)
      // You could add a toast notification here
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Cover Image */}
      <div className="relative h-64 md:h-80 bg-gradient-to-r from-midnight-blue to-electric-purple">
        <img
          src={mockPhotographer.coverImage || "/placeholder.svg"}
          alt="Photography work"
          className="w-full h-full object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />

        {/* Back Button */}
        <Button asChild variant="outline" size="sm" className="absolute top-4 left-4 bg-background/80 backdrop-blur">
          <Link href="/client-dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Search
          </Link>
        </Button>

        {/* Share Button */}
        <Button
          onClick={handleShare}
          variant="outline"
          size="sm"
          className="absolute top-4 right-4 bg-background/80 backdrop-blur"
        >
          <Share2 className="h-4 w-4 mr-2" />
          Share
        </Button>
      </div>

      <div className="container mx-auto px-4 -mt-20 relative z-10">
        {/* Profile Header */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <Avatar className="w-24 h-24 border-4 border-background">
                <AvatarImage src={mockPhotographer.image || "/placeholder.svg"} alt={mockPhotographer.name} />
                <AvatarFallback>
                  {mockPhotographer.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                  <div>
                    <h1 className="text-3xl font-bold text-midnight-blue dark:text-white mb-2">
                      {mockPhotographer.name}
                    </h1>
                    <div className="flex items-center gap-4 text-muted-foreground mb-2">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                        <span className="font-medium">{mockPhotographer.rating}</span>
                        <span className="ml-1">({mockPhotographer.reviewCount} reviews)</span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {mockPhotographer.location}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {mockPhotographer.specialties.map((specialty) => (
                        <Badge key={specialty} variant="secondary">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-3 mt-4 md:mt-0">
                    <Button asChild className="bg-electric-purple hover:bg-electric-purple/90">
                      <Link href={`/book/${mockPhotographer.id}`}>
                        <Calendar className="h-4 w-4 mr-2" />
                        Book Session
                      </Link>
                    </Button>
                    <Button variant="outline" className="border-neon-cyan hover:bg-neon-cyan/10 bg-transparent">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Message
                    </Button>
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-muted rounded-lg">
                  <div className="text-center">
                    <div className="font-semibold text-neon-cyan">{mockPhotographer.experience}</div>
                    <div className="text-sm text-muted-foreground">Experience</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-electric-purple">{mockPhotographer.completedSessions}</div>
                    <div className="text-sm text-muted-foreground">Sessions</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-neon-cyan">{mockPhotographer.responseTime}</div>
                    <div className="text-sm text-muted-foreground">Response</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-electric-purple">{mockPhotographer.price}</div>
                    <div className="text-sm text-muted-foreground">Starting at</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="packages">Packages</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
          </TabsList>

          <TabsContent value="portfolio" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockPhotographer.portfolio.map((image, index) => (
                <div key={index} className="aspect-square overflow-hidden rounded-lg">
                  <img
                    src={image || "/placeholder.svg"}
                    alt={`Portfolio ${index + 1}`}
                    className="w-full h-full object-cover hover:scale-105 transition-transform cursor-pointer"
                  />
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="about" className="mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>About Me</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">{mockPhotographer.bio}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Camera className="h-5 w-5 mr-2 text-neon-cyan" />
                    Equipment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {mockPhotographer.equipment.map((item, index) => (
                      <li key={index} className="flex items-center text-muted-foreground">
                        <span className="w-2 h-2 bg-electric-purple rounded-full mr-3"></span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="packages" className="mt-6">
            <div className="grid md:grid-cols-3 gap-6">
              {mockPhotographer.packages.map((pkg, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-xl">{pkg.name}</CardTitle>
                    <CardDescription className="text-2xl font-bold text-neon-cyan">{pkg.price}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center text-muted-foreground">
                      <Clock className="h-4 w-4 mr-2" />
                      {pkg.duration}
                    </div>
                    <div className="flex items-center text-muted-foreground">
                      <Camera className="h-4 w-4 mr-2" />
                      {pkg.photos}
                    </div>
                    <ul className="space-y-2">
                      {pkg.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center text-sm">
                          <span className="w-2 h-2 bg-electric-purple rounded-full mr-3"></span>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Button asChild className="w-full bg-electric-purple hover:bg-electric-purple/90">
                      <Link href={`/book/${mockPhotographer.id}?package=${index}`}>Select Package</Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="reviews" className="mt-6">
            <div className="space-y-6">
              {mockPhotographer.reviews.map((review) => (
                <Card key={review.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarFallback>
                            {review.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-semibold">{review.name}</div>
                          <div className="flex items-center space-x-2">
                            <div className="flex">
                              {[...Array(review.rating)].map((_, i) => (
                                <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                              ))}
                            </div>
                            <span className="text-sm text-muted-foreground">{review.date}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <p className="text-muted-foreground">{review.comment}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
