"use client"

import { useState } from "react"
import Link from "next/link"
import {
  Calendar,
  MessageCircle,
  Camera,
  Settings,
  Upload,
  Clock,
  DollarSign,
  Star,
  TrendingUp,
  Eye,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { ProtectedRoute } from "@/components/protected-route"

// Mock data for photographer dashboard
const mockStats = {
  totalBookings: 127,
  monthlyEarnings: 8500,
  portfolioViews: 2340,
  averageRating: 4.9,
  completionRate: 98,
  responseTime: "2 hours",
}

const mockRecentBookings = [
  {
    id: "1",
    clientName: "Emily Chen",
    clientImage: "/placeholder.svg",
    service: "Wedding Photography",
    date: "2024-03-15",
    time: "2:00 PM",
    status: "Confirmed",
    amount: "$2,500",
  },
  {
    id: "2",
    clientName: "Michael Rodriguez",
    clientImage: "/placeholder.svg",
    service: "Portrait Session",
    date: "2024-02-28",
    time: "10:00 AM",
    status: "Pending",
    amount: "$200",
  },
  {
    id: "3",
    clientName: "Jessica Park",
    clientImage: "/placeholder.svg",
    service: "Engagement Photos",
    date: "2024-02-25",
    time: "4:00 PM",
    status: "Completed",
    amount: "$400",
  },
]

const mockMessages = [
  {
    id: "1",
    clientName: "Sarah Johnson",
    message: "Hi! I'm interested in booking a wedding session for June.",
    timestamp: "2 hours ago",
    unread: true,
  },
  {
    id: "2",
    clientName: "David Kim",
    message: "Thank you for the amazing photos!",
    timestamp: "1 day ago",
    unread: false,
  },
  {
    id: "3",
    clientName: "Lisa Wang",
    message: "Can we reschedule our session to next week?",
    timestamp: "2 days ago",
    unread: true,
  },
]

export default function PhotographerDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState("month")

  return (
    <ProtectedRoute requiredRole="photographer">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-midnight-blue dark:text-white mb-2">Photographer Dashboard</h1>
            <p className="text-muted-foreground">Manage your photography business</p>
          </div>

          <div className="flex gap-3 mt-4 md:mt-0">
            <Button asChild variant="outline" className="border-neon-cyan hover:bg-neon-cyan/10 bg-transparent">
              <Link href="/photographer-bookings">
                <Calendar className="h-4 w-4 mr-2" />
                View Bookings
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="border-electric-purple hover:bg-electric-purple/10 bg-transparent"
            >
              <Link href="/photographer-messages">
                <MessageCircle className="h-4 w-4 mr-2" />
                Messages
              </Link>
            </Button>
            <Button asChild className="bg-electric-purple hover:bg-electric-purple/90">
              <Link href="/manage-portfolio">
                <Camera className="h-4 w-4 mr-2" />
                Manage Portfolio
              </Link>
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Bookings</CardTitle>
              <Calendar className="h-4 w-4 text-neon-cyan" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-neon-cyan">{mockStats.totalBookings}</div>
              <p className="text-xs text-muted-foreground">+12% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monthly Earnings</CardTitle>
              <DollarSign className="h-4 w-4 text-electric-purple" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-electric-purple">
                ${mockStats.monthlyEarnings.toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">+8% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Portfolio Views</CardTitle>
              <Eye className="h-4 w-4 text-neon-cyan" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-neon-cyan">{mockStats.portfolioViews.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">+15% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
              <Star className="h-4 w-4 text-electric-purple" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-electric-purple">{mockStats.averageRating}</div>
              <p className="text-xs text-muted-foreground">Based on 127 reviews</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Manage your photography business efficiently</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button asChild className="h-auto p-4 flex-col bg-neon-cyan text-midnight-blue hover:bg-neon-cyan/90">
                <Link href="/manage-portfolio">
                  <Upload className="h-6 w-6 mb-2" />
                  <span className="font-medium">Upload Photos</span>
                  <span className="text-xs opacity-80">Add to portfolio</span>
                </Link>
              </Button>

              <Button
                asChild
                variant="outline"
                className="h-auto p-4 flex-col border-electric-purple hover:bg-electric-purple/10 bg-transparent"
              >
                <Link href="/set-availability">
                  <Clock className="h-6 w-6 mb-2 text-electric-purple" />
                  <span className="font-medium">Set Availability</span>
                  <span className="text-xs text-muted-foreground">Update calendar</span>
                </Link>
              </Button>

              <Button
                asChild
                variant="outline"
                className="h-auto p-4 flex-col border-neon-cyan hover:bg-neon-cyan/10 bg-transparent"
              >
                <Link href="/drive-management">
                  <Camera className="h-6 w-6 mb-2 text-neon-cyan" />
                  <span className="font-medium">Manage Drives</span>
                  <span className="text-xs text-muted-foreground">Client photo delivery</span>
                </Link>
              </Button>

              <Button asChild variant="outline" className="h-auto p-4 flex-col bg-transparent">
                <Link href="/photographer-profile">
                  <Settings className="h-6 w-6 mb-2" />
                  <span className="font-medium">Profile Settings</span>
                  <span className="text-xs text-muted-foreground">Update info</span>
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Bookings */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Bookings</CardTitle>
                <Button asChild variant="outline" size="sm">
                  <Link href="/photographer-bookings">View All</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockRecentBookings.map((booking) => (
                  <div key={booking.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={booking.clientImage || "/placeholder.svg"} alt={booking.clientName} />
                        <AvatarFallback>
                          {booking.clientName
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{booking.clientName}</p>
                        <p className="text-sm text-muted-foreground">{booking.service}</p>
                        <p className="text-xs text-muted-foreground">
                          {booking.date} at {booking.time}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge
                        className={
                          booking.status === "Confirmed"
                            ? "bg-green-500 hover:bg-green-600"
                            : booking.status === "Pending"
                              ? "bg-yellow-500 hover:bg-yellow-600"
                              : "bg-blue-500 hover:bg-blue-600"
                        }
                      >
                        {booking.status}
                      </Badge>
                      <p className="text-sm font-medium text-neon-cyan mt-1">{booking.amount}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Messages */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Messages</CardTitle>
                <Button asChild variant="outline" size="sm">
                  <Link href="/photographer-messages">View All</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockMessages.map((message) => (
                  <div key={message.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback>
                        {message.clientName
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium">{message.clientName}</p>
                        <div className="flex items-center space-x-2">
                          {message.unread && <div className="w-2 h-2 bg-neon-cyan rounded-full"></div>}
                          <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{message.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Performance Metrics */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-electric-purple" />
              Performance Metrics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Booking Completion Rate</span>
                  <span className="text-sm text-neon-cyan">{mockStats.completionRate}%</span>
                </div>
                <Progress value={mockStats.completionRate} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Client Satisfaction</span>
                  <span className="text-sm text-electric-purple">96%</span>
                </div>
                <Progress value={96} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Response Time</span>
                  <span className="text-sm text-neon-cyan">{mockStats.responseTime}</span>
                </div>
                <div className="text-xs text-muted-foreground">Average response to messages</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </ProtectedRoute>
  )
}
