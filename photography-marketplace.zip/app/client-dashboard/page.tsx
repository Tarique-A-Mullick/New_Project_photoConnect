"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, MapPin, Calendar, MessageCircle, Settings, Star, Camera } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ProtectedRoute } from "@/components/protected-route"

// Mock data for photographers
const mockPhotographers = [
  {
    id: "1",
    name: "Sarah Johnson",
    specialties: ["Wedding", "Portrait"],
    location: "New York, NY",
    rating: 4.9,
    reviewCount: 127,
    price: "$200/hour",
    availability: "Available",
    image: "/professional-female-photographer.png",
    featured: true,
  },
  {
    id: "2",
    name: "Michael Chen",
    specialties: ["Event", "Corporate"],
    location: "Los Angeles, CA",
    rating: 4.8,
    reviewCount: 89,
    price: "$150/hour",
    availability: "Busy",
    image: "/placeholder-vc3ml.png",
    featured: false,
  },
  {
    id: "3",
    name: "Emma Rodriguez",
    specialties: ["Fashion", "Portrait"],
    location: "Miami, FL",
    rating: 4.9,
    reviewCount: 156,
    price: "$250/hour",
    availability: "Available",
    image: "/female-fashion-photographer.png",
    featured: true,
  },
  {
    id: "4",
    name: "David Kim",
    specialties: ["Wedding", "Engagement"],
    location: "Seattle, WA",
    rating: 4.7,
    reviewCount: 203,
    price: "$180/hour",
    availability: "Available",
    image: "/placeholder-hdwun.png",
    featured: false,
  },
]

export default function ClientDashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [locationFilter, setLocationFilter] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [priceFilter, setPriceFilter] = useState("")
  const [availabilityFilter, setAvailabilityFilter] = useState("all")

  const filteredPhotographers = mockPhotographers.filter((photographer) => {
    const matchesSearch =
      photographer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      photographer.specialties.some((specialty) => specialty.toLowerCase().includes(searchQuery.toLowerCase()))
    const matchesLocation =
      !locationFilter || photographer.location.toLowerCase().includes(locationFilter.toLowerCase())
    const matchesCategory = categoryFilter === "all" || photographer.specialties.includes(categoryFilter)
    const matchesAvailability = availabilityFilter === "all" || photographer.availability === availabilityFilter

    return matchesSearch && matchesLocation && matchesCategory && matchesAvailability
  })

  const featuredPhotographers = filteredPhotographers.filter((p) => p.featured)
  const regularPhotographers = filteredPhotographers.filter((p) => !p.featured)

  return (
    <ProtectedRoute requiredRole="client">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-midnight-blue dark:text-white mb-2">
              Find Your Perfect Photographer
            </h1>
            <p className="text-muted-foreground">Discover talented photographers for your special moments</p>
          </div>

          <div className="flex gap-3 mt-4 md:mt-0">
            <Button asChild variant="outline" className="border-neon-cyan hover:bg-neon-cyan/10 bg-transparent">
              <Link href="/client-bookings">
                <Calendar className="h-4 w-4 mr-2" />
                My Bookings
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="border-electric-purple hover:bg-electric-purple/10 bg-transparent"
            >
              <Link href="/client-messages">
                <MessageCircle className="h-4 w-4 mr-2" />
                Messages
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/client-profile">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Link>
            </Button>
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Search className="h-5 w-5 mr-2 text-neon-cyan" />
              Search & Filter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="lg:col-span-2">
                <Label htmlFor="search">Search photographers</Label>
                <Input
                  id="search"
                  placeholder="Name or specialty..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="focus:ring-neon-cyan focus:border-neon-cyan"
                />
              </div>

              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  placeholder="City, State"
                  value={locationFilter}
                  onChange={(e) => setLocationFilter(e.target.value)}
                  className="focus:ring-neon-cyan focus:border-neon-cyan"
                />
              </div>

              <div>
                <Label htmlFor="category">Category</Label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All categories</SelectItem>
                    <SelectItem value="Wedding">Wedding</SelectItem>
                    <SelectItem value="Portrait">Portrait</SelectItem>
                    <SelectItem value="Event">Event</SelectItem>
                    <SelectItem value="Fashion">Fashion</SelectItem>
                    <SelectItem value="Corporate">Corporate</SelectItem>
                    <SelectItem value="Engagement">Engagement</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="availability">Availability</Label>
                <Select value={availabilityFilter} onValueChange={setAvailabilityFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="Available">Available</SelectItem>
                    <SelectItem value="Busy">Busy</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Featured Photographers */}
        {featuredPhotographers.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-midnight-blue dark:text-white mb-4 flex items-center">
              <Star className="h-6 w-6 mr-2 text-electric-purple" />
              Featured Photographers Near You
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredPhotographers.map((photographer) => (
                <PhotographerCard key={photographer.id} photographer={photographer} featured />
              ))}
            </div>
          </div>
        )}

        {/* All Photographers */}
        <div>
          <h2 className="text-2xl font-bold text-midnight-blue dark:text-white mb-4">
            All Photographers ({regularPhotographers.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {regularPhotographers.map((photographer) => (
              <PhotographerCard key={photographer.id} photographer={photographer} />
            ))}
          </div>
        </div>

        {filteredPhotographers.length === 0 && (
          <div className="text-center py-12">
            <Camera className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-muted-foreground mb-2">No photographers found</h3>
            <p className="text-muted-foreground">Try adjusting your search criteria</p>
          </div>
        )}
      </div>
    </ProtectedRoute>
  )
}

function PhotographerCard({ photographer, featured = false }: { photographer: any; featured?: boolean }) {
  return (
    <Card className={`hover:shadow-lg transition-shadow ${featured ? "ring-2 ring-electric-purple" : ""}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <img
              src={photographer.image || "/placeholder.svg"}
              alt={photographer.name}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <CardTitle className="text-lg">{photographer.name}</CardTitle>
              <div className="flex items-center space-x-1">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="text-sm font-medium">{photographer.rating}</span>
                <span className="text-sm text-muted-foreground">({photographer.reviewCount})</span>
              </div>
            </div>
          </div>
          {featured && <Badge className="bg-electric-purple hover:bg-electric-purple/90">Featured</Badge>}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex items-center text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 mr-1" />
          {photographer.location}
        </div>

        <div className="flex flex-wrap gap-1">
          {photographer.specialties.map((specialty) => (
            <Badge key={specialty} variant="secondary" className="text-xs">
              {specialty}
            </Badge>
          ))}
        </div>

        <div className="flex items-center justify-between">
          <span className="font-semibold text-neon-cyan">{photographer.price}</span>
          <Badge
            variant={photographer.availability === "Available" ? "default" : "secondary"}
            className={photographer.availability === "Available" ? "bg-green-500 hover:bg-green-600" : ""}
          >
            {photographer.availability}
          </Badge>
        </div>

        <div className="flex gap-2">
          <Button asChild size="sm" className="flex-1 bg-electric-purple hover:bg-electric-purple/90">
            <Link href={`/photographer/${photographer.id}`}>View Profile</Link>
          </Button>
          <Button asChild size="sm" variant="outline" className="border-neon-cyan hover:bg-neon-cyan/10 bg-transparent">
            <Link href={`/book/${photographer.id}`}>Book Now</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
