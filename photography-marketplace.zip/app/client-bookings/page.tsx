"use client"

import Link from "next/link"
import { Calendar, Clock, MapPin, Camera, MessageCircle, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProtectedRoute } from "@/components/protected-route"

// Mock booking data
const mockBookings = {
  upcoming: [
    {
      id: "1",
      photographerName: "Sarah Johnson",
      photographerImage: "/professional-female-photographer.png",
      service: "Wedding Photography",
      date: "2024-03-15",
      time: "2:00 PM",
      duration: "8 hours",
      location: "Central Park, NYC",
      status: "Confirmed",
      price: "$2,500",
    },
    {
      id: "2",
      photographerName: "Michael Chen",
      photographerImage: "/placeholder-vc3ml.png",
      service: "Corporate Headshots",
      date: "2024-02-28",
      time: "10:00 AM",
      duration: "2 hours",
      location: "Downtown Office",
      status: "Pending",
      price: "$300",
    },
  ],
  past: [
    {
      id: "3",
      photographerName: "Emma Rodriguez",
      photographerImage: "/female-fashion-photographer.png",
      service: "Engagement Session",
      date: "2024-01-20",
      time: "4:00 PM",
      duration: "2 hours",
      location: "Brooklyn Bridge",
      status: "Completed",
      price: "$400",
      rating: 5,
      photosDelivered: true,
    },
  ],
}

export default function ClientBookings() {
  return (
    <ProtectedRoute requiredRole="client">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-midnight-blue dark:text-white mb-2">My Bookings</h1>
            <p className="text-muted-foreground">Manage your photography sessions</p>
          </div>
          <Button asChild className="bg-electric-purple hover:bg-electric-purple/90">
            <Link href="/client-dashboard">
              <Camera className="h-4 w-4 mr-2" />
              Find Photographers
            </Link>
          </Button>
        </div>

        <Tabs defaultValue="upcoming" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="upcoming">Upcoming ({mockBookings.upcoming.length})</TabsTrigger>
            <TabsTrigger value="past">Past ({mockBookings.past.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="mt-6">
            <div className="space-y-4">
              {mockBookings.upcoming.map((booking) => (
                <BookingCard key={booking.id} booking={booking} type="upcoming" />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="past" className="mt-6">
            <div className="space-y-4">
              {mockBookings.past.map((booking) => (
                <BookingCard key={booking.id} booking={booking} type="past" />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </ProtectedRoute>
  )
}

function BookingCard({ booking, type }: { booking: any; type: "upcoming" | "past" }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Confirmed":
        return "bg-green-500 hover:bg-green-600"
      case "Pending":
        return "bg-yellow-500 hover:bg-yellow-600"
      case "Completed":
        return "bg-blue-500 hover:bg-blue-600"
      default:
        return "bg-gray-500 hover:bg-gray-600"
    }
  }

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Photographer Info */}
          <div className="flex items-center space-x-4">
            <img
              src={booking.photographerImage || "/placeholder.svg"}
              alt={booking.photographerName}
              className="w-16 h-16 rounded-full object-cover"
            />
            <div>
              <h3 className="font-semibold text-lg">{booking.photographerName}</h3>
              <p className="text-muted-foreground">{booking.service}</p>
              <Badge className={getStatusColor(booking.status)}>{booking.status}</Badge>
            </div>
          </div>

          {/* Booking Details */}
          <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <div>
                <div className="font-medium text-foreground">{booking.date}</div>
                <div className="text-sm">{booking.time}</div>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-muted-foreground">
              <Clock className="h-4 w-4" />
              <div>
                <div className="font-medium text-foreground">{booking.duration}</div>
                <div className="text-sm">Duration</div>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <div>
                <div className="font-medium text-foreground">{booking.location}</div>
                <div className="text-sm">Location</div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-2 min-w-[120px]">
            <div className="text-right">
              <div className="font-bold text-neon-cyan text-lg">{booking.price}</div>
            </div>

            {type === "upcoming" && (
              <>
                <Button size="sm" variant="outline" className="border-neon-cyan hover:bg-neon-cyan/10 bg-transparent">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Message
                </Button>
                <Button size="sm" variant="outline">
                  View Details
                </Button>
              </>
            )}

            {type === "past" && (
              <>
                {booking.photosDelivered && (
                  <Button size="sm" className="bg-electric-purple hover:bg-electric-purple/90">
                    View Photos
                  </Button>
                )}
                {booking.rating && (
                  <div className="flex items-center justify-center space-x-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{booking.rating}</span>
                  </div>
                )}
                <Button size="sm" variant="outline">
                  Book Again
                </Button>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
