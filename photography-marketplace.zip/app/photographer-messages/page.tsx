"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Search, Send, User, MoreVertical } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ProtectedRoute } from "@/components/protected-route"

// Mock conversation data for photographer
const mockConversations = [
  {
    id: "1",
    clientName: "Emily Chen",
    clientImage: "/placeholder.svg",
    lastMessage: "Thank you for accepting our booking! We're so excited.",
    timestamp: "1 hour ago",
    unread: 1,
    online: true,
  },
  {
    id: "2",
    clientName: "Michael Rodriguez",
    clientImage: "/placeholder.svg",
    lastMessage: "What time works best for the headshot session?",
    timestamp: "3 hours ago",
    unread: 0,
    online: false,
  },
  {
    id: "3",
    clientName: "Jessica Park",
    clientImage: "/placeholder.svg",
    lastMessage: "The engagement photos are absolutely beautiful!",
    timestamp: "1 day ago",
    unread: 2,
    online: true,
  },
]

const mockMessages = [
  {
    id: "1",
    sender: "client",
    message: "Hi! I'm interested in booking you for our wedding on March 15th. Are you available?",
    timestamp: "Yesterday 2:30 PM",
  },
  {
    id: "2",
    sender: "photographer",
    message:
      "Hello Emily! Yes, I'm available on March 15th. I'd love to capture your special day! What time is the ceremony?",
    timestamp: "Yesterday 3:15 PM",
  },
  {
    id: "3",
    sender: "client",
    message: "The ceremony starts at 2 PM at Central Park. We'd like coverage for about 8 hours total.",
    timestamp: "Yesterday 3:30 PM",
  },
  {
    id: "4",
    sender: "photographer",
    message:
      "Perfect! For 8 hours of wedding coverage, my rate is $2,500. This includes the ceremony, reception, and all edited photos delivered within 2 weeks. Would you like to proceed?",
    timestamp: "Yesterday 4:00 PM",
  },
  {
    id: "5",
    sender: "client",
    message: "That sounds perfect! How do we move forward with the booking?",
    timestamp: "Yesterday 4:15 PM",
  },
  {
    id: "6",
    sender: "photographer",
    message:
      "Great! I'll send you a contract and invoice. A 50% deposit secures your date, with the remainder due on the wedding day.",
    timestamp: "Yesterday 4:30 PM",
  },
  {
    id: "7",
    sender: "client",
    message: "Thank you for accepting our booking! We're so excited.",
    timestamp: "1 hour ago",
  },
]

export default function PhotographerMessages() {
  const [selectedConversation, setSelectedConversation] = useState(mockConversations[0])
  const [newMessage, setNewMessage] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  const filteredConversations = mockConversations.filter((conversation) =>
    conversation.clientName.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // TODO: Implement send message logic
      console.log("Sending message:", newMessage)
      setNewMessage("")
    }
  }

  return (
    <ProtectedRoute requiredRole="photographer">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="flex items-center mb-8">
          <Button asChild variant="outline" size="sm" className="mr-4 bg-transparent">
            <Link href="/photographer-dashboard">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-midnight-blue dark:text-white">Messages</h1>
            <p className="text-muted-foreground">Chat with your clients</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
          {/* Conversations List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Client Conversations</CardTitle>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search clients..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 focus:ring-neon-cyan focus:border-neon-cyan"
                />
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-1">
                {filteredConversations.map((conversation) => (
                  <div
                    key={conversation.id}
                    onClick={() => setSelectedConversation(conversation)}
                    className={`p-4 cursor-pointer hover:bg-muted/50 transition-colors ${
                      selectedConversation.id === conversation.id ? "bg-muted" : ""
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <Avatar>
                          <AvatarImage
                            src={conversation.clientImage || "/placeholder.svg"}
                            alt={conversation.clientName}
                          />
                          <AvatarFallback>
                            {conversation.clientName
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        {conversation.online && (
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-background rounded-full"></div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium truncate">{conversation.clientName}</h4>
                          <div className="flex items-center space-x-2">
                            {conversation.unread > 0 && (
                              <Badge className="bg-neon-cyan text-midnight-blue hover:bg-neon-cyan/90">
                                {conversation.unread}
                              </Badge>
                            )}
                            <span className="text-xs text-muted-foreground">{conversation.timestamp}</span>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">{conversation.lastMessage}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Chat Area */}
          <Card className="lg:col-span-2 flex flex-col">
            {/* Chat Header */}
            <CardHeader className="flex-shrink-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar>
                      <AvatarImage
                        src={selectedConversation.clientImage || "/placeholder.svg"}
                        alt={selectedConversation.clientName}
                      />
                      <AvatarFallback>
                        {selectedConversation.clientName
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    {selectedConversation.online && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-background rounded-full"></div>
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold">{selectedConversation.clientName}</h3>
                    <p className="text-sm text-muted-foreground">
                      {selectedConversation.online ? "Online" : "Last seen 3 hours ago"}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Button
                    asChild
                    size="sm"
                    variant="outline"
                    className="border-neon-cyan hover:bg-neon-cyan/10 bg-transparent"
                  >
                    <Link href={`/client-profile/${selectedConversation.id}`}>
                      <User className="h-4 w-4 mr-2" />
                      View Profile
                    </Link>
                  </Button>
                  <Button size="sm" variant="outline">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            <Separator />

            {/* Messages */}
            <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
              {mockMessages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === "photographer" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[70%] p-3 rounded-lg ${
                      message.sender === "photographer" ? "bg-electric-purple text-white" : "bg-muted text-foreground"
                    }`}
                  >
                    <p className="text-sm">{message.message}</p>
                    <p
                      className={`text-xs mt-1 ${
                        message.sender === "photographer" ? "text-white/70" : "text-muted-foreground"
                      }`}
                    >
                      {message.timestamp}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>

            <Separator />

            {/* Message Input */}
            <div className="p-4 flex-shrink-0">
              <div className="flex space-x-2">
                <Input
                  placeholder="Type your message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  className="flex-1 focus:ring-neon-cyan focus:border-neon-cyan"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim()}
                  className="bg-electric-purple hover:bg-electric-purple/90"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  )
}
