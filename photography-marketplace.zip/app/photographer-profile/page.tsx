"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, User, Camera, DollarSign, Eye, EyeOff, Plus, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { ProtectedRoute } from "@/components/protected-route"
import { useAuth } from "@/contexts/auth-context"
import { useToast } from "@/hooks/use-toast"

export default function PhotographerProfile() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isEditing, setIsEditing] = useState(false)
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)

  const [profileData, setProfileData] = useState({
    fullName: user?.fullName || "",
    email: user?.email || "",
    phone: "",
    location: "New York, NY",
    bio: "Professional wedding and portrait photographer with over 8 years of experience. I specialize in capturing authentic moments and emotions that tell your unique story.",
    experience: "8+ years",
    specialties: ["Wedding", "Portrait", "Engagement"],
    equipment: ["Canon EOS R5", "Canon 24-70mm f/2.8L", "Canon 85mm f/1.4L", "Professional lighting kit"],
    packages: [
      {
        name: "Basic Portrait Session",
        price: "$200",
        duration: "1 hour",
        description: "Perfect for individual or couple portraits",
      },
      {
        name: "Wedding Photography",
        price: "$2,500",
        duration: "8 hours",
        description: "Complete wedding day coverage",
      },
    ],
    paymentInfo: {
      upiId: "photographer@upi",
      bankAccount: "**** **** **** 1234",
    },
    preferences: {
      emailNotifications: true,
      smsNotifications: true,
      marketingEmails: false,
      publicProfile: true,
    },
  })

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  const [newSpecialty, setNewSpecialty] = useState("")
  const [newEquipment, setNewEquipment] = useState("")

  const handleSaveProfile = () => {
    toast({
      title: "Profile updated",
      description: "Your profile has been successfully updated.",
    })
    setIsEditing(false)
  }

  const handleChangePassword = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Password mismatch",
        description: "New passwords don't match. Please try again.",
        variant: "destructive",
      })
      return
    }

    toast({
      title: "Password changed",
      description: "Your password has been successfully updated.",
    })
    setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" })
  }

  const addSpecialty = () => {
    if (newSpecialty && !profileData.specialties.includes(newSpecialty)) {
      setProfileData({
        ...profileData,
        specialties: [...profileData.specialties, newSpecialty],
      })
      setNewSpecialty("")
    }
  }

  const removeSpecialty = (specialty: string) => {
    setProfileData({
      ...profileData,
      specialties: profileData.specialties.filter((s) => s !== specialty),
    })
  }

  const addEquipment = () => {
    if (newEquipment && !profileData.equipment.includes(newEquipment)) {
      setProfileData({
        ...profileData,
        equipment: [...profileData.equipment, newEquipment],
      })
      setNewEquipment("")
    }
  }

  const removeEquipment = (equipment: string) => {
    setProfileData({
      ...profileData,
      equipment: profileData.equipment.filter((e) => e !== equipment),
    })
  }

  return (
    <ProtectedRoute requiredRole="photographer">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex items-center mb-8">
          <Button asChild variant="outline" size="sm" className="mr-4 bg-transparent">
            <Link href="/photographer-dashboard">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-midnight-blue dark:text-white">Profile Settings</h1>
            <p className="text-muted-foreground">Manage your photographer profile and business information</p>
          </div>
        </div>

        <div className="grid gap-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <User className="h-5 w-5 mr-2 text-neon-cyan" />
                    Basic Information
                  </CardTitle>
                  <CardDescription>Update your personal and contact information</CardDescription>
                </div>
                <Button
                  onClick={() => (isEditing ? handleSaveProfile() : setIsEditing(true))}
                  className={isEditing ? "bg-electric-purple hover:bg-electric-purple/90" : ""}
                  variant={isEditing ? "default" : "outline"}
                >
                  {isEditing ? "Save Changes" : "Edit Profile"}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input
                    id="fullName"
                    value={profileData.fullName}
                    onChange={(e) => setProfileData({ ...profileData, fullName: e.target.value })}
                    disabled={!isEditing}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profileData.email}
                    onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                    disabled={!isEditing}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="(555) 123-4567"
                    value={profileData.phone}
                    onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                    disabled={!isEditing}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    placeholder="City, State"
                    value={profileData.location}
                    onChange={(e) => setProfileData({ ...profileData, location: e.target.value })}
                    disabled={!isEditing}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="experience">Experience</Label>
                  <Input
                    id="experience"
                    placeholder="e.g., 5+ years"
                    value={profileData.experience}
                    onChange={(e) => setProfileData({ ...profileData, experience: e.target.value })}
                    disabled={!isEditing}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Professional Bio</Label>
                <Textarea
                  id="bio"
                  placeholder="Tell clients about your photography style and experience..."
                  value={profileData.bio}
                  onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                  disabled={!isEditing}
                  className="focus:ring-neon-cyan focus:border-neon-cyan"
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          {/* Specialties */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Camera className="h-5 w-5 mr-2 text-electric-purple" />
                Photography Specialties
              </CardTitle>
              <CardDescription>Add your areas of expertise</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {profileData.specialties.map((specialty) => (
                  <Badge key={specialty} variant="secondary" className="flex items-center gap-1">
                    {specialty}
                    {isEditing && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-4 w-4 p-0 hover:bg-transparent"
                        onClick={() => removeSpecialty(specialty)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    )}
                  </Badge>
                ))}
              </div>

              {isEditing && (
                <div className="flex gap-2">
                  <Input
                    placeholder="Add specialty (e.g., Fashion, Corporate)"
                    value={newSpecialty}
                    onChange={(e) => setNewSpecialty(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addSpecialty()}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                  <Button onClick={addSpecialty} size="sm" className="bg-electric-purple hover:bg-electric-purple/90">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Equipment */}
          <Card>
            <CardHeader>
              <CardTitle>Camera Equipment</CardTitle>
              <CardDescription>List your professional equipment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                {profileData.equipment.map((item) => (
                  <div key={item} className="flex items-center justify-between p-2 border rounded">
                    <span className="text-sm">{item}</span>
                    {isEditing && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => removeEquipment(item)}
                        className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              {isEditing && (
                <div className="flex gap-2">
                  <Input
                    placeholder="Add equipment (e.g., Canon 85mm f/1.4L)"
                    value={newEquipment}
                    onChange={(e) => setNewEquipment(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addEquipment()}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                  <Button onClick={addEquipment} size="sm" className="bg-electric-purple hover:bg-electric-purple/90">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Pricing Packages */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="h-5 w-5 mr-2 text-neon-cyan" />
                Pricing Packages
              </CardTitle>
              <CardDescription>Manage your service packages and pricing</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {profileData.packages.map((pkg, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>Package Name</Label>
                      <Input
                        value={pkg.name}
                        disabled={!isEditing}
                        className="focus:ring-neon-cyan focus:border-neon-cyan"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Price</Label>
                      <Input
                        value={pkg.price}
                        disabled={!isEditing}
                        className="focus:ring-neon-cyan focus:border-neon-cyan"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Duration</Label>
                      <Input
                        value={pkg.duration}
                        disabled={!isEditing}
                        className="focus:ring-neon-cyan focus:border-neon-cyan"
                      />
                    </div>
                  </div>
                  <div className="mt-4 space-y-2">
                    <Label>Description</Label>
                    <Textarea
                      value={pkg.description}
                      disabled={!isEditing}
                      className="focus:ring-neon-cyan focus:border-neon-cyan"
                      rows={2}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Payment Information */}
          <Card>
            <CardHeader>
              <CardTitle>Payment Information</CardTitle>
              <CardDescription>Update your payment details for client transactions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="upiId">UPI ID</Label>
                  <Input
                    id="upiId"
                    placeholder="your-upi@bank"
                    value={profileData.paymentInfo.upiId}
                    onChange={(e) =>
                      setProfileData({
                        ...profileData,
                        paymentInfo: { ...profileData.paymentInfo, upiId: e.target.value },
                      })
                    }
                    disabled={!isEditing}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bankAccount">Bank Account</Label>
                  <Input
                    id="bankAccount"
                    placeholder="Account number (last 4 digits shown)"
                    value={profileData.paymentInfo.bankAccount}
                    disabled={!isEditing}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Privacy Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Privacy & Notifications</CardTitle>
              <CardDescription>Control your privacy and notification preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Public Profile</Label>
                  <p className="text-sm text-muted-foreground">Allow clients to find and view your profile</p>
                </div>
                <Switch
                  checked={profileData.preferences.publicProfile}
                  onCheckedChange={(checked) =>
                    setProfileData({
                      ...profileData,
                      preferences: { ...profileData.preferences, publicProfile: checked },
                    })
                  }
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">Receive booking requests and updates via email</p>
                </div>
                <Switch
                  checked={profileData.preferences.emailNotifications}
                  onCheckedChange={(checked) =>
                    setProfileData({
                      ...profileData,
                      preferences: { ...profileData.preferences, emailNotifications: checked },
                    })
                  }
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>SMS Notifications</Label>
                  <p className="text-sm text-muted-foreground">Receive urgent notifications via text message</p>
                </div>
                <Switch
                  checked={profileData.preferences.smsNotifications}
                  onCheckedChange={(checked) =>
                    setProfileData({
                      ...profileData,
                      preferences: { ...profileData.preferences, smsNotifications: checked },
                    })
                  }
                />
              </div>
            </CardContent>
          </Card>

          {/* Change Password */}
          <Card>
            <CardHeader>
              <CardTitle>Change Password</CardTitle>
              <CardDescription>Update your account password</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currentPassword">Current Password</Label>
                <div className="relative">
                  <Input
                    id="currentPassword"
                    type={showCurrentPassword ? "text" : "password"}
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                    className="focus:ring-neon-cyan focus:border-neon-cyan pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  >
                    {showCurrentPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="newPassword">New Password</Label>
                  <div className="relative">
                    <Input
                      id="newPassword"
                      type={showNewPassword ? "text" : "password"}
                      value={passwordData.newPassword}
                      onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                      className="focus:ring-neon-cyan focus:border-neon-cyan pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                    >
                      {showNewPassword ? (
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm New Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>
              </div>

              <Button
                onClick={handleChangePassword}
                className="bg-electric-purple hover:bg-electric-purple/90"
                disabled={!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword}
              >
                Update Password
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  )
}
