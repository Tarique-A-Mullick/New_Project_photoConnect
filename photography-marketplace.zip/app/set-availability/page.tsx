"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Calendar, Clock, Save, Plus, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { ProtectedRoute } from "@/components/protected-route"
import { useToast } from "@/hooks/use-toast"

// Mock availability data
const mockAvailability = {
  "2024-02-15": { available: true, timeSlots: ["9:00 AM", "1:00 PM", "4:00 PM"] },
  "2024-02-16": { available: true, timeSlots: ["10:00 AM", "2:00 PM"] },
  "2024-02-17": { available: false, timeSlots: [] },
  "2024-02-18": { available: true, timeSlots: ["9:00 AM", "11:00 AM", "3:00 PM", "5:00 PM"] },
  "2024-02-19": { available: true, timeSlots: ["10:00 AM", "2:00 PM", "4:00 PM"] },
  "2024-02-20": { available: false, timeSlots: [] },
  "2024-02-21": { available: true, timeSlots: ["9:00 AM", "1:00 PM"] },
}

const timeSlotOptions = [
  "9:00 AM",
  "10:00 AM",
  "11:00 AM",
  "12:00 PM",
  "1:00 PM",
  "2:00 PM",
  "3:00 PM",
  "4:00 PM",
  "5:00 PM",
  "6:00 PM",
]

export default function SetAvailability() {
  const [availability, setAvailability] = useState(mockAvailability)
  const [selectedDate, setSelectedDate] = useState("2024-02-15")
  const [currentMonth, setCurrentMonth] = useState(new Date(2024, 1)) // February 2024
  const { toast } = useToast()

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear()
    const month = date.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    const days = []

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null)
    }

    // Add all days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day))
    }

    return days
  }

  const formatDate = (date: Date) => {
    return date.toISOString().split("T")[0]
  }

  const toggleDayAvailability = (date: string) => {
    setAvailability((prev) => ({
      ...prev,
      [date]: {
        ...prev[date],
        available: !prev[date]?.available,
        timeSlots: prev[date]?.available ? [] : ["9:00 AM", "1:00 PM", "4:00 PM"],
      },
    }))
  }

  const addTimeSlot = (date: string, timeSlot: string) => {
    setAvailability((prev) => ({
      ...prev,
      [date]: {
        ...prev[date],
        available: true,
        timeSlots: [...(prev[date]?.timeSlots || []), timeSlot].sort(),
      },
    }))
  }

  const removeTimeSlot = (date: string, timeSlot: string) => {
    setAvailability((prev) => ({
      ...prev,
      [date]: {
        ...prev[date],
        timeSlots: prev[date]?.timeSlots.filter((slot) => slot !== timeSlot) || [],
      },
    }))
  }

  const handleSave = () => {
    // TODO: Implement save logic
    toast({
      title: "Availability updated",
      description: "Your availability has been successfully saved.",
    })
  }

  const days = getDaysInMonth(currentMonth)
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  return (
    <ProtectedRoute requiredRole="photographer">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Button asChild variant="outline" size="sm" className="mr-4 bg-transparent">
              <Link href="/photographer-dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-midnight-blue dark:text-white">Set Availability</h1>
              <p className="text-muted-foreground">Manage your calendar and time slots</p>
            </div>
          </div>

          <Button onClick={handleSave} className="bg-electric-purple hover:bg-electric-purple/90">
            <Save className="h-4 w-4 mr-2" />
            Save Changes
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Calendar */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-neon-cyan" />
                  {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                </CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
                  >
                    Next
                  </Button>
                </div>
              </div>
              <CardDescription>Click on dates to toggle availability</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2 mb-4">
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                  <div key={day} className="text-center text-sm font-medium text-muted-foreground p-2">
                    {day}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-2">
                {days.map((day, index) => {
                  if (!day) {
                    return <div key={index} className="p-2" />
                  }

                  const dateString = formatDate(day)
                  const dayAvailability = availability[dateString]
                  const isSelected = selectedDate === dateString
                  const isAvailable = dayAvailability?.available
                  const hasTimeSlots = dayAvailability?.timeSlots?.length > 0

                  return (
                    <Button
                      key={dateString}
                      variant={isSelected ? "default" : "outline"}
                      className={`
                        h-12 p-2 relative
                        ${isSelected ? "bg-electric-purple hover:bg-electric-purple/90" : ""}
                        ${isAvailable && !isSelected ? "border-neon-cyan bg-neon-cyan/10" : ""}
                        ${!isAvailable && !isSelected ? "border-red-300 bg-red-50 dark:bg-red-950/20" : ""}
                      `}
                      onClick={() => {
                        setSelectedDate(dateString)
                        if (!dayAvailability) {
                          toggleDayAvailability(dateString)
                        }
                      }}
                    >
                      <div className="text-center">
                        <div className="text-sm font-medium">{day.getDate()}</div>
                        {hasTimeSlots && (
                          <div className="text-xs opacity-75">{dayAvailability.timeSlots.length} slots</div>
                        )}
                      </div>
                    </Button>
                  )
                })}
              </div>

              <div className="flex items-center justify-center gap-6 mt-6 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-neon-cyan bg-neon-cyan/10 rounded"></div>
                  <span>Available</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-red-300 bg-red-50 dark:bg-red-950/20 rounded"></div>
                  <span>Unavailable</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-electric-purple rounded"></div>
                  <span>Selected</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Time Slots */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2 text-electric-purple" />
                Time Slots
              </CardTitle>
              <CardDescription>
                {selectedDate ? `Manage slots for ${new Date(selectedDate).toLocaleDateString()}` : "Select a date"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedDate && (
                <>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="day-available">Day Available</Label>
                    <Switch
                      id="day-available"
                      checked={availability[selectedDate]?.available || false}
                      onCheckedChange={() => toggleDayAvailability(selectedDate)}
                    />
                  </div>

                  {availability[selectedDate]?.available && (
                    <>
                      <div className="space-y-2">
                        <Label>Current Time Slots</Label>
                        <div className="space-y-2">
                          {availability[selectedDate]?.timeSlots?.map((slot) => (
                            <div key={slot} className="flex items-center justify-between p-2 border rounded">
                              <span className="text-sm">{slot}</span>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => removeTimeSlot(selectedDate, slot)}
                                className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          )) || <p className="text-sm text-muted-foreground">No time slots set</p>}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Add Time Slot</Label>
                        <Select
                          onValueChange={(value) => {
                            if (!availability[selectedDate]?.timeSlots?.includes(value)) {
                              addTimeSlot(selectedDate, value)
                            }
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select time slot" />
                          </SelectTrigger>
                          <SelectContent>
                            {timeSlotOptions
                              .filter((slot) => !availability[selectedDate]?.timeSlots?.includes(slot))
                              .map((slot) => (
                                <SelectItem key={slot} value={slot}>
                                  {slot}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full border-neon-cyan hover:bg-neon-cyan/10 bg-transparent"
                        onClick={() => {
                          const defaultSlots = ["9:00 AM", "1:00 PM", "4:00 PM"]
                          defaultSlots.forEach((slot) => {
                            if (!availability[selectedDate]?.timeSlots?.includes(slot)) {
                              addTimeSlot(selectedDate, slot)
                            }
                          })
                        }}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Default Slots
                      </Button>
                    </>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  )
}
