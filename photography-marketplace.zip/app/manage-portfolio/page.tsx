"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Upload, Edit, Trash2, GripVertical, Tag, ImageIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ProtectedRoute } from "@/components/protected-route"

// Mock portfolio data
const mockPortfolioItems = [
  {
    id: "1",
    title: "Elegant Wedding Ceremony",
    image: "/wedding-ceremony.png",
    category: "Wedding",
    tags: ["ceremony", "elegant", "outdoor"],
    description: "Beautiful outdoor wedding ceremony captured in golden hour lighting.",
    uploadDate: "2024-01-15",
    views: 234,
    likes: 45,
  },
  {
    id: "2",
    title: "Professional Headshots",
    image: "/portrait-couple.png",
    category: "Portrait",
    tags: ["headshot", "professional", "studio"],
    description: "Corporate headshots with professional lighting setup.",
    uploadDate: "2024-01-10",
    views: 189,
    likes: 32,
  },
  {
    id: "3",
    title: "Romantic Engagement Session",
    image: "/outdoor-engagement.png",
    category: "Engagement",
    tags: ["engagement", "romantic", "sunset"],
    description: "Romantic engagement photos during sunset at the beach.",
    uploadDate: "2024-01-05",
    views: 156,
    likes: 28,
  },
  {
    id: "4",
    title: "Family Portrait Session",
    image: "/family-portrait.png",
    category: "Family",
    tags: ["family", "portrait", "outdoor"],
    description: "Warm family portraits in a natural outdoor setting.",
    uploadDate: "2024-01-01",
    views: 203,
    likes: 41,
  },
]

const categories = ["All", "Wedding", "Portrait", "Engagement", "Family", "Event", "Fashion", "Corporate"]

export default function ManagePortfolio() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [portfolioItems, setPortfolioItems] = useState(mockPortfolioItems)
  const [editingItem, setEditingItem] = useState(null)
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false)

  const filteredItems = portfolioItems.filter(
    (item) => selectedCategory === "All" || item.category === selectedCategory,
  )

  const [newItem, setNewItem] = useState({
    title: "",
    category: "",
    tags: "",
    description: "",
  })

  const handleUpload = () => {
    // TODO: Implement actual upload logic
    console.log("Uploading new portfolio item:", newItem)
    setIsUploadDialogOpen(false)
    setNewItem({ title: "", category: "", tags: "", description: "" })
  }

  const handleDelete = (id: string) => {
    setPortfolioItems(portfolioItems.filter((item) => item.id !== id))
  }

  return (
    <ProtectedRoute requiredRole="photographer">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Button asChild variant="outline" size="sm" className="mr-4 bg-transparent">
              <Link href="/photographer-dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-midnight-blue dark:text-white">Manage Portfolio</h1>
              <p className="text-muted-foreground">Upload and organize your photography work</p>
            </div>
          </div>

          <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-electric-purple hover:bg-electric-purple/90">
                <Upload className="h-4 w-4 mr-2" />
                Upload Photos
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Upload New Photos</DialogTitle>
                <DialogDescription>Add new photos to your portfolio</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    placeholder="Photo title"
                    value={newItem.title}
                    onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={newItem.category}
                    onValueChange={(value) => setNewItem({ ...newItem, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.slice(1).map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tags">Tags</Label>
                  <Input
                    id="tags"
                    placeholder="wedding, outdoor, elegant (comma separated)"
                    value={newItem.tags}
                    onChange={(e) => setNewItem({ ...newItem, tags: e.target.value })}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe this photo..."
                    value={newItem.description}
                    onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                    rows={3}
                  />
                </div>

                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                  <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-sm text-muted-foreground mb-2">Drag and drop photos here, or click to browse</p>
                  <Button variant="outline" size="sm">
                    Choose Files
                  </Button>
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleUpload} className="flex-1 bg-electric-purple hover:bg-electric-purple/90">
                    Upload Photos
                  </Button>
                  <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-neon-cyan">{portfolioItems.length}</div>
              <p className="text-sm text-muted-foreground">Total Photos</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-electric-purple">
                {portfolioItems.reduce((sum, item) => sum + item.views, 0)}
              </div>
              <p className="text-sm text-muted-foreground">Total Views</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-neon-cyan">
                {portfolioItems.reduce((sum, item) => sum + item.likes, 0)}
              </div>
              <p className="text-sm text-muted-foreground">Total Likes</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-electric-purple">{categories.length - 1}</div>
              <p className="text-sm text-muted-foreground">Categories</p>
            </CardContent>
          </Card>
        </div>

        {/* Category Filter */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filter by Category</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={
                    selectedCategory === category
                      ? "bg-electric-purple hover:bg-electric-purple/90"
                      : "border-neon-cyan hover:bg-neon-cyan/10 bg-transparent"
                  }
                >
                  {category}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} className="group hover:shadow-lg transition-shadow">
              <div className="relative aspect-square overflow-hidden rounded-t-lg">
                <img
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex gap-1">
                    <Button size="sm" variant="secondary" className="h-8 w-8 p-0">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      className="h-8 w-8 p-0"
                      onClick={() => handleDelete(item.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="absolute top-2 left-2">
                  <Badge className="bg-electric-purple hover:bg-electric-purple/90">{item.category}</Badge>
                </div>
                <div className="absolute bottom-2 left-2 right-2">
                  <div className="flex items-center justify-between text-white text-sm">
                    <span>{item.views} views</span>
                    <span>{item.likes} likes</span>
                  </div>
                </div>
              </div>

              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold truncate">{item.title}</h3>
                  <Button size="sm" variant="ghost" className="h-6 w-6 p-0 cursor-grab">
                    <GripVertical className="h-4 w-4" />
                  </Button>
                </div>

                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{item.description}</p>

                <div className="flex flex-wrap gap-1 mb-3">
                  {item.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      <Tag className="h-3 w-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                  {item.tags.length > 3 && (
                    <Badge variant="secondary" className="text-xs">
                      +{item.tags.length - 3}
                    </Badge>
                  )}
                </div>

                <div className="text-xs text-muted-foreground">Uploaded {item.uploadDate}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <ImageIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-muted-foreground mb-2">No photos found</h3>
            <p className="text-muted-foreground mb-4">
              {selectedCategory === "All"
                ? "Upload your first photos to get started"
                : `No photos in ${selectedCategory} category`}
            </p>
            <Button
              onClick={() => setIsUploadDialogOpen(true)}
              className="bg-electric-purple hover:bg-electric-purple/90"
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload Photos
            </Button>
          </div>
        )}
      </div>
    </ProtectedRoute>
  )
}
