"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Plus, QrCode, Upload, Eye, Lock, Unlock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ProtectedRoute } from "@/components/protected-route"
import { useToast } from "@/hooks/use-toast"

// Mock drive data
const mockDrives = [
  {
    id: "1",
    clientName: "Emily Chen",
    eventName: "Wedding Photography",
    createdDate: "2024-02-15",
    expiryDate: "2024-05-15",
    totalPhotos: 245,
    totalSize: "2.1 GB",
    storageUsed: 85,
    isPasswordProtected: true,
    qrCode: "QR_CODE_1",
    status: "Active",
    accessCount: 12,
    lastAccessed: "2024-02-20",
  },
  {
    id: "2",
    clientName: "Michael Rodriguez",
    eventName: "Portrait Session",
    createdDate: "2024-02-10",
    expiryDate: "2024-05-10",
    totalPhotos: 45,
    totalSize: "380 MB",
    storageUsed: 15,
    isPasswordProtected: false,
    qrCode: "QR_CODE_2",
    status: "Active",
    accessCount: 5,
    lastAccessed: "2024-02-18",
  },
  {
    id: "3",
    clientName: "Jessica Park",
    eventName: "Engagement Photos",
    createdDate: "2024-01-25",
    expiryDate: "2024-04-25",
    totalPhotos: 78,
    totalSize: "650 MB",
    storageUsed: 26,
    isPasswordProtected: true,
    qrCode: "QR_CODE_3",
    status: "Expired",
    accessCount: 8,
    lastAccessed: "2024-02-01",
  },
]

const storagePlans = [
  {
    name: "Basic",
    storage: "5 GB",
    price: "$9.99/month",
    features: ["5GB storage", "Up to 500 photos", "3 months retention"],
  },
  {
    name: "Professional",
    storage: "25 GB",
    price: "$19.99/month",
    features: ["25GB storage", "Up to 2500 photos", "6 months retention", "Priority support"],
  },
  {
    name: "Premium",
    storage: "100 GB",
    price: "$39.99/month",
    features: ["100GB storage", "Unlimited photos", "12 months retention", "Priority support", "Custom branding"],
  },
]

export default function DriveManagement() {
  const [drives, setDrives] = useState(mockDrives)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState("Professional")
  const { toast } = useToast()

  const [newDrive, setNewDrive] = useState({
    clientName: "",
    eventName: "",
    password: "",
    expiryMonths: "3",
  })

  const handleCreateDrive = () => {
    // TODO: Implement actual drive creation logic
    toast({
      title: "Drive created successfully",
      description: `Photo drive for ${newDrive.clientName} has been created.`,
    })
    setIsCreateDialogOpen(false)
    setNewDrive({ clientName: "", eventName: "", password: "", expiryMonths: "3" })
  }

  const generateQRCode = (driveId: string) => {
    // TODO: Implement QR code generation
    toast({
      title: "QR Code generated",
      description: "QR code has been generated and copied to clipboard.",
    })
  }

  const togglePassword = (driveId: string) => {
    setDrives(
      drives.map((drive) =>
        drive.id === driveId ? { ...drive, isPasswordProtected: !drive.isPasswordProtected } : drive,
      ),
    )
  }

  return (
    <ProtectedRoute requiredRole="photographer">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Button asChild variant="outline" size="sm" className="mr-4 bg-transparent">
              <Link href="/photographer-dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-midnight-blue dark:text-white">Drive Management</h1>
              <p className="text-muted-foreground">Manage client photo delivery drives</p>
            </div>
          </div>

          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-electric-purple hover:bg-electric-purple/90">
                <Plus className="h-4 w-4 mr-2" />
                Create New Drive
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Client Drive</DialogTitle>
                <DialogDescription>Set up a new photo delivery drive for your client</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="clientName">Client Name</Label>
                  <Input
                    id="clientName"
                    placeholder="Enter client name"
                    value={newDrive.clientName}
                    onChange={(e) => setNewDrive({ ...newDrive, clientName: e.target.value })}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="eventName">Event/Session Name</Label>
                  <Input
                    id="eventName"
                    placeholder="e.g., Wedding Photography, Portrait Session"
                    value={newDrive.eventName}
                    onChange={(e) => setNewDrive({ ...newDrive, eventName: e.target.value })}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Optional Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Leave empty for no password"
                    value={newDrive.password}
                    onChange={(e) => setNewDrive({ ...newDrive, password: e.target.value })}
                    className="focus:ring-neon-cyan focus:border-neon-cyan"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="expiry">Drive Expiry</Label>
                  <Select
                    value={newDrive.expiryMonths}
                    onValueChange={(value) => setNewDrive({ ...newDrive, expiryMonths: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 Month</SelectItem>
                      <SelectItem value="3">3 Months</SelectItem>
                      <SelectItem value="6">6 Months</SelectItem>
                      <SelectItem value="12">12 Months</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleCreateDrive} className="flex-1 bg-electric-purple hover:bg-electric-purple/90">
                    Create Drive
                  </Button>
                  <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Storage Plan */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Current Storage Plan</CardTitle>
            <CardDescription>Manage your storage subscription</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {storagePlans.map((plan) => (
                <Card
                  key={plan.name}
                  className={`cursor-pointer transition-colors ${
                    selectedPlan === plan.name ? "ring-2 ring-electric-purple" : ""
                  }`}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{plan.name}</CardTitle>
                      {selectedPlan === plan.name && (
                        <Badge className="bg-electric-purple hover:bg-electric-purple/90">Current</Badge>
                      )}
                    </div>
                    <div className="text-2xl font-bold text-neon-cyan">{plan.price}</div>
                    <div className="text-sm text-muted-foreground">{plan.storage}</div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <ul className="space-y-1 text-sm">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-center">
                          <span className="w-2 h-2 bg-electric-purple rounded-full mr-2"></span>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    {selectedPlan !== plan.name && (
                      <Button
                        className="w-full mt-4 bg-electric-purple hover:bg-electric-purple/90"
                        onClick={() => setSelectedPlan(plan.name)}
                      >
                        Upgrade
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Drives List */}
        <div className="space-y-4">
          {drives.map((drive) => (
            <Card key={drive.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row gap-6">
                  {/* Drive Info */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold">{drive.clientName}</h3>
                        <p className="text-muted-foreground">{drive.eventName}</p>
                        <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                          <span>Created: {drive.createdDate}</span>
                          <span>Expires: {drive.expiryDate}</span>
                        </div>
                      </div>
                      <Badge
                        className={
                          drive.status === "Active" ? "bg-green-500 hover:bg-green-600" : "bg-red-500 hover:bg-red-600"
                        }
                      >
                        {drive.status}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <div className="text-sm text-muted-foreground">Photos</div>
                        <div className="font-semibold text-neon-cyan">{drive.totalPhotos}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Size</div>
                        <div className="font-semibold text-electric-purple">{drive.totalSize}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Access Count</div>
                        <div className="font-semibold">{drive.accessCount}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Last Accessed</div>
                        <div className="font-semibold">{drive.lastAccessed}</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Storage Used</span>
                        <span>{drive.storageUsed}%</span>
                      </div>
                      <Progress value={drive.storageUsed} className="h-2" />
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-2 min-w-[200px]">
                    <Button
                      size="sm"
                      className="bg-neon-cyan text-midnight-blue hover:bg-neon-cyan/90"
                      onClick={() => generateQRCode(drive.id)}
                    >
                      <QrCode className="h-4 w-4 mr-2" />
                      Generate QR
                    </Button>

                    <Button
                      size="sm"
                      variant="outline"
                      className="border-electric-purple hover:bg-electric-purple/10 bg-transparent"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Photos
                    </Button>

                    <Button size="sm" variant="outline" className="bg-transparent">
                      <Eye className="h-4 w-4 mr-2" />
                      View Access Log
                    </Button>

                    <div className="flex items-center justify-between p-2 border rounded">
                      <div className="flex items-center gap-2">
                        {drive.isPasswordProtected ? (
                          <Lock className="h-4 w-4 text-green-500" />
                        ) : (
                          <Unlock className="h-4 w-4 text-red-500" />
                        )}
                        <span className="text-sm">Password</span>
                      </div>
                      <Switch
                        checked={drive.isPasswordProtected}
                        onCheckedChange={() => togglePassword(drive.id)}
                        size="sm"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {drives.length === 0 && (
          <div className="text-center py-12">
            <Upload className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-muted-foreground mb-2">No drives created yet</h3>
            <p className="text-muted-foreground mb-4">Create your first client drive to start delivering photos</p>
            <Button
              onClick={() => setIsCreateDialogOpen(true)}
              className="bg-electric-purple hover:bg-electric-purple/90"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create New Drive
            </Button>
          </div>
        )}
      </div>
    </ProtectedRoute>
  )
}
