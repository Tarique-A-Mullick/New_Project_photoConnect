import Link from "next/link"
import { Camera, Users, Calendar, ImageIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function HomePage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-6xl font-bold text-midnight-blue dark:text-white mb-6">
          Connect with Professional
          <span className="text-neon-cyan"> Photographers</span>
        </h1>
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Find the perfect photographer for your special moments. Book sessions, view portfolios, and get your photos
          delivered seamlessly.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg" className="bg-electric-purple hover:bg-electric-purple/90">
            <Link href="/register">Get Started</Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="border-neon-cyan hover:bg-neon-cyan/10 bg-transparent">
            <Link href="/login">Sign In</Link>
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
        <Card className="text-center">
          <CardHeader>
            <Users className="h-12 w-12 text-neon-cyan mx-auto mb-4" />
            <CardTitle>Find Photographers</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Browse profiles, portfolios, and reviews to find the perfect photographer for your needs.
            </CardDescription>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader>
            <Calendar className="h-12 w-12 text-electric-purple mx-auto mb-4" />
            <CardTitle>Easy Booking</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>Schedule sessions with integrated calendar and secure payment processing.</CardDescription>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader>
            <ImageIcon className="h-12 w-12 text-neon-cyan mx-auto mb-4" />
            <CardTitle>Photo Delivery</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Receive your photos through secure, password-protected drives with QR access.
            </CardDescription>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader>
            <Camera className="h-12 w-12 text-electric-purple mx-auto mb-4" />
            <CardTitle>Portfolio Management</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Photographers can showcase their work and manage bookings all in one place.
            </CardDescription>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
