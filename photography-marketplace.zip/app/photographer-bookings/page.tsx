"use client"

import Link from "next/link"
import { ArrowLeft, Calendar, Clock, MapPin, MessageCircle, Check, X, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ProtectedRoute } from "@/components/protected-route"

// Mock booking data for photographer
const mockBookings = {
  pending: [
    {
      id: "1",
      clientName: "Emily Chen",
      clientImage: "/placeholder.svg",
      service: "Wedding Photography",
      date: "2024-03-15",
      time: "2:00 PM",
      duration: "8 hours",
      location: "Central Park, NYC",
      status: "Pending",
      price: "$2,500",
      message: "Looking forward to capturing your special day!",
    },
    {
      id: "2",
      clientName: "Michael Rodriguez",
      clientImage: "/placeholder.svg",
      service: "Corporate Headshots",
      date: "2024-02-28",
      time: "10:00 AM",
      duration: "2 hours",
      location: "Downtown Office",
      status: "Pending",
      price: "$300",
      message: "Professional headshots for LinkedIn profile.",
    },
  ],
  confirmed: [
    {
      id: "3",
      clientName: "Jessica Park",
      clientImage: "/placeholder.svg",
      service: "Engagement Session",
      date: "2024-02-25",
      time: "4:00 PM",
      duration: "2 hours",
      location: "Brooklyn Bridge",
      status: "Confirmed",
      price: "$400",
      message: "Excited for our engagement photos!",
    },
  ],
  completed: [
    {
      id: "4",
      clientName: "David Kim",
      clientImage: "/placeholder.svg",
      service: "Family Portrait",
      date: "2024-01-20",
      time: "11:00 AM",
      duration: "1.5 hours",
      location: "Central Park",
      status: "Completed",
      price: "$350",
      rating: 5,
      review: "Amazing photographer! Captured beautiful family moments.",
      photosDelivered: true,
    },
  ],
}

export default function PhotographerBookings() {
  const handleAcceptBooking = (bookingId: string) => {
    // TODO: Implement accept booking logic
    console.log("Accepting booking:", bookingId)
  }

  const handleDeclineBooking = (bookingId: string) => {
    // TODO: Implement decline booking logic
    console.log("Declining booking:", bookingId)
  }

  return (
    <ProtectedRoute requiredRole="photographer">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Button asChild variant="outline" size="sm" className="mr-4 bg-transparent">
              <Link href="/photographer-dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-midnight-blue dark:text-white">My Bookings</h1>
              <p className="text-muted-foreground">Manage your photography sessions</p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="pending" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="pending">Pending ({mockBookings.pending.length})</TabsTrigger>
            <TabsTrigger value="confirmed">Confirmed ({mockBookings.confirmed.length})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({mockBookings.completed.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="mt-6">
            <div className="space-y-4">
              {mockBookings.pending.map((booking) => (
                <BookingCard
                  key={booking.id}
                  booking={booking}
                  type="pending"
                  onAccept={() => handleAcceptBooking(booking.id)}
                  onDecline={() => handleDeclineBooking(booking.id)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="confirmed" className="mt-6">
            <div className="space-y-4">
              {mockBookings.confirmed.map((booking) => (
                <BookingCard key={booking.id} booking={booking} type="confirmed" />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="completed" className="mt-6">
            <div className="space-y-4">
              {mockBookings.completed.map((booking) => (
                <BookingCard key={booking.id} booking={booking} type="completed" />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </ProtectedRoute>
  )
}

function BookingCard({
  booking,
  type,
  onAccept,
  onDecline,
}: {
  booking: any
  type: "pending" | "confirmed" | "completed"
  onAccept?: () => void
  onDecline?: () => void
}) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Confirmed":
        return "bg-green-500 hover:bg-green-600"
      case "Pending":
        return "bg-yellow-500 hover:bg-yellow-600"
      case "Completed":
        return "bg-blue-500 hover:bg-blue-600"
      default:
        return "bg-gray-500 hover:bg-gray-600"
    }
  }

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Client Info */}
          <div className="flex items-center space-x-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={booking.clientImage || "/placeholder.svg"} alt={booking.clientName} />
              <AvatarFallback>
                {booking.clientName
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold text-lg">{booking.clientName}</h3>
              <p className="text-muted-foreground">{booking.service}</p>
              <Badge className={getStatusColor(booking.status)}>{booking.status}</Badge>
            </div>
          </div>

          {/* Booking Details */}
          <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <div>
                <div className="font-medium text-foreground">{booking.date}</div>
                <div className="text-sm">{booking.time}</div>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-muted-foreground">
              <Clock className="h-4 w-4" />
              <div>
                <div className="font-medium text-foreground">{booking.duration}</div>
                <div className="text-sm">Duration</div>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <div>
                <div className="font-medium text-foreground">{booking.location}</div>
                <div className="text-sm">Location</div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-2 min-w-[140px]">
            <div className="text-right">
              <div className="font-bold text-neon-cyan text-lg">{booking.price}</div>
            </div>

            {type === "pending" && (
              <>
                <Button size="sm" className="bg-green-500 hover:bg-green-600" onClick={onAccept}>
                  <Check className="h-4 w-4 mr-2" />
                  Accept
                </Button>
                <Button size="sm" variant="destructive" onClick={onDecline}>
                  <X className="h-4 w-4 mr-2" />
                  Decline
                </Button>
                <Button size="sm" variant="outline" className="border-neon-cyan hover:bg-neon-cyan/10 bg-transparent">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Message
                </Button>
              </>
            )}

            {type === "confirmed" && (
              <>
                <Button size="sm" variant="outline" className="border-neon-cyan hover:bg-neon-cyan/10 bg-transparent">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Message
                </Button>
                <Button size="sm" variant="outline">
                  <Eye className="h-4 w-4 mr-2" />
                  View Details
                </Button>
              </>
            )}

            {type === "completed" && (
              <>
                {booking.photosDelivered && (
                  <Badge className="bg-electric-purple hover:bg-electric-purple/90 justify-center">
                    Photos Delivered
                  </Badge>
                )}
                {booking.rating && (
                  <div className="text-center">
                    <div className="text-sm text-muted-foreground">Client Rating</div>
                    <div className="font-semibold text-yellow-500">{booking.rating}/5 ⭐</div>
                  </div>
                )}
                <Button size="sm" variant="outline">
                  View Review
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Message/Review */}
        {booking.message && (
          <div className="mt-4 p-3 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground italic">"{booking.message}"</p>
          </div>
        )}

        {booking.review && (
          <div className="mt-4 p-3 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground italic">"{booking.review}"</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
