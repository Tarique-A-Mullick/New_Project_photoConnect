"use client"

import Link from "next/link"
import { Camera, User, UserCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function RoleSelectionPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted p-4">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-8">
          <Camera className="h-16 w-16 text-neon-cyan mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-midnight-blue dark:text-white mb-2">Choose Your Role</h1>
          <p className="text-muted-foreground">Select how you'd like to use PhotoConnect</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Client Card */}
          <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
            <CardHeader className="text-center pb-4">
              <User className="h-16 w-16 text-neon-cyan mx-auto mb-4 group-hover:scale-110 transition-transform" />
              <CardTitle className="text-2xl text-midnight-blue dark:text-white">I'm a Client</CardTitle>
              <CardDescription className="text-base">
                Looking to hire professional photographers for events, portraits, or special occasions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-neon-cyan rounded-full mr-3"></span>
                  Browse photographer portfolios
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-neon-cyan rounded-full mr-3"></span>
                  Book photography sessions
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-neon-cyan rounded-full mr-3"></span>
                  Receive photos securely
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-neon-cyan rounded-full mr-3"></span>
                  Chat with photographers
                </li>
              </ul>
              <Button asChild className="w-full bg-neon-cyan text-midnight-blue hover:bg-neon-cyan/90">
                <Link href="/client-dashboard">Enter as Client</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Photographer Card */}
          <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
            <CardHeader className="text-center pb-4">
              <UserCheck className="h-16 w-16 text-electric-purple mx-auto mb-4 group-hover:scale-110 transition-transform" />
              <CardTitle className="text-2xl text-midnight-blue dark:text-white">I'm a Photographer</CardTitle>
              <CardDescription className="text-base">
                Professional photographer ready to showcase work and connect with clients
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-electric-purple rounded-full mr-3"></span>
                  Create stunning portfolios
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-electric-purple rounded-full mr-3"></span>
                  Manage bookings & availability
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-electric-purple rounded-full mr-3"></span>
                  Deliver photos to clients
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-electric-purple rounded-full mr-3"></span>
                  Grow your business
                </li>
              </ul>
              <Button asChild className="w-full bg-electric-purple hover:bg-electric-purple/90">
                <Link href="/photographer-dashboard">Enter as Photographer</Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-8">
          <p className="text-sm text-muted-foreground">
            Need to change your selection later?{" "}
            <Link href="/login" className="text-neon-cyan hover:text-neon-cyan/80 transition-colors">
              Visit your profile settings
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
